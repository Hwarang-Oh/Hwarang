package com.ssafy.day5.b_interface.relation;

// TODO: DigitalCamera를 충전 가능하게 설정하시오.
public class DigitalCamera extends Camera{
    // TODO: Chargeable을 구현하시오.

    // END
}
