package com.ssafy.day5.b_interface.module;

public interface Printer {
    void print(String fileName);
}
