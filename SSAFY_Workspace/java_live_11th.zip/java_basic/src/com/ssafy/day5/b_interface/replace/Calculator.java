package com.ssafy.day5.b_interface.replace;

public interface Calculator {
  int add(int a, int b);
}
