package com.ssafy.day5.b_interface.relation;

public class Camera {

}
