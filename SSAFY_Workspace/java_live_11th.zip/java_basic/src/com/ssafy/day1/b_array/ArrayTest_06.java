package com.ssafy.day1.b_array;

public class ArrayTest_06 {

    public static void main(String[] args) {
        int[] ints = new int[3];
        ints[2] = 10;

        char[] chars = { 'S', 'S', 'A', 'F', 'Y' };

        String[] strs = { "S", "S", "A", "F", "Y" };

        boolean[] bools;
        bools={true,false,false};
    }
}
