package com.ssafy.day1.b_array;

public class ArrayTest_07 {
    public static void main(String[] args) {
        // TODO: 4명의 친구 이름을 관리하는 배열을 만들고 내용을 출력하시오.

        // END
    }
}
