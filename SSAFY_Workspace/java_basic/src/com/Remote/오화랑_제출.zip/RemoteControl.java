package com.Remote;

public interface RemoteControl {
	void volumeUp();
	void volumeDown();
	void Power();
}
